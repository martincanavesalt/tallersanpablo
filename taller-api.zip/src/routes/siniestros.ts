import { randomUUID } from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import {
  ESTADOS,
  TIPOS_COBERTURA,
  TRANSICIONES,
  documentosObligatorios,
  type TipoCobertura,
} from "../constants";
import { prisma } from "../db";
import type { Prisma } from "../../generated/prisma/client";
import { HttpError } from "../errors";
import { idParam, montoSchema, normalizarDni, normalizarPatente, sucursalFiltro } from "../lib/util";
import { usuarioActual, type UsuarioAuth } from "../middleware/auth";

// Se monta detrás de requireUsuario
export const siniestrosRouter = Router();

const detalle = {
  sucursal: { select: { id: true, nombre: true } },
  auto: {
    include: {
      cliente: { select: { id: true, dni: true, nombre: true, apellido: true, telefono: true, email: true } },
    },
  },
  documentos: { orderBy: { id: "asc" } },
  historialEstados: {
    orderBy: { fecha: "asc" },
    include: { usuario: { select: { nombre: true } } },
  },
} satisfies Prisma.SiniestroInclude;

type SiniestroDetallado = Prisma.SiniestroGetPayload<{ include: typeof detalle }>;

// Un EMPLEADO que pide un siniestro de otra sucursal recibe 404, como si no existiera
export async function cargarSiniestro(u: UsuarioAuth, id: number): Promise<SiniestroDetallado> {
  const s = await prisma.siniestro.findFirst({
    where: { id, sucursalId: sucursalFiltro(u) },
    include: detalle,
  });
  if (!s) throw new HttpError(404, "Siniestro no encontrado");
  return s;
}

// Lo que se devuelve al frontend: sin claves internas del storage
function presentar(s: SiniestroDetallado) {
  const { documentos, ...resto } = s;
  const docs = documentos.map((d) => ({
    id: d.id,
    tipoDocumento: d.tipoDocumento,
    obligatorio: d.obligatorio,
    cargado: d.archivoUrl !== null,
    formato: d.formato,
    fechaCarga: d.fechaCarga,
  }));
  return {
    ...resto,
    documentos: docs,
    documentosFaltantes: docs.filter((d) => d.obligatorio && !d.cargado).map((d) => d.tipoDocumento),
  };
}

const coberturaValida = (d: { tipoCobertura: TipoCobertura; montoFranquicia?: number | null }) =>
  d.tipoCobertura === "TODO_RIESGO_FRANQUICIA"
    ? d.montoFranquicia !== undefined && d.montoFranquicia !== null
    : d.montoFranquicia === undefined || d.montoFranquicia === null;

const MSG_FRANQUICIA = "montoFranquicia es obligatorio solo cuando la cobertura es TODO_RIESGO_FRANQUICIA";

// ── Alta ──────────────────────────────────────────────────────────

const crearSchema = z
  .object({
    autoId: z.number().int().positive(),
    tipoCobertura: z.enum(TIPOS_COBERTURA),
    montoFranquicia: montoSchema.optional(),
    // Si no se manda, el sistema genera SIN-000123
    numeroSiniestro: z.string().trim().min(1).max(50).optional(),
    descripcion: z.string().trim().max(2000).optional(),
    fechaEstimada: z.coerce.date().optional(),
    // Solo lo usa un ADMIN; un EMPLEADO siempre carga en su sucursal
    sucursalId: z.number().int().positive().optional(),
  })
  .refine(coberturaValida, { message: MSG_FRANQUICIA, path: ["montoFranquicia"] });

siniestrosRouter.post("/", async (req, res) => {
  const u = usuarioActual(req);
  const d = crearSchema.parse(req.body);

  const sucursalId = u.rol === "EMPLEADO" ? u.sucursalId : d.sucursalId;
  if (!sucursalId) throw new HttpError(400, "Un administrador debe indicar la sucursalId");
  if (!(await prisma.sucursal.findUnique({ where: { id: sucursalId }, select: { id: true } }))) {
    throw new HttpError(400, "La sucursal no existe");
  }
  if (!(await prisma.auto.findUnique({ where: { id: d.autoId }, select: { id: true } }))) {
    throw new HttpError(404, "Auto no encontrado");
  }
  if (d.numeroSiniestro) {
    const repetido = await prisma.siniestro.findUnique({ where: { numeroSiniestro: d.numeroSiniestro }, select: { id: true } });
    if (repetido) throw new HttpError(409, "Ya existe un siniestro con ese número", { siniestroId: repetido.id });
  }

  const creado = await prisma.$transaction(async (tx) => {
    const s = await tx.siniestro.create({
      data: {
        numeroSiniestro: d.numeroSiniestro ?? `TMP-${randomUUID()}`,
        tipoCobertura: d.tipoCobertura,
        montoFranquicia: d.montoFranquicia,
        descripcion: d.descripcion,
        fechaEstimada: d.fechaEstimada,
        autoId: d.autoId,
        sucursalId,
        usuarioCargaId: u.id,
      },
    });
    if (!d.numeroSiniestro) {
      await tx.siniestro.update({
        where: { id: s.id },
        data: { numeroSiniestro: `SIN-${String(s.id).padStart(6, "0")}` },
      });
    }
    await tx.historialEstado.create({
      data: { estadoAnterior: null, estadoNuevo: "INGRESADO", comentario: "Ingreso al taller", siniestroId: s.id, usuarioId: u.id },
    });
    // Checklist automático de documentos obligatorios (archivo pendiente)
    await tx.documento.createMany({
      data: documentosObligatorios(d.tipoCobertura).map((t) => ({
        siniestroId: s.id,
        tipoDocumento: t,
        obligatorio: true,
      })),
    });
    return s.id;
  });

  res.status(201).json(presentar(await cargarSiniestro(u, creado)));
});

// ── Consulta ──────────────────────────────────────────────────────

siniestrosRouter.get("/", async (req, res) => {
  const u = usuarioActual(req);
  const q = z
    .object({
      estado: z.enum(ESTADOS).optional(),
      activos: z.enum(["true", "false"]).optional(),
      sucursalId: z.coerce.number().int().positive().optional(),
      q: z.string().trim().max(60).optional(),
      pagina: z.coerce.number().int().min(1).default(1),
    })
    .parse(req.query);

  const or: Prisma.SiniestroWhereInput[] = [];
  if (q.q) {
    or.push(
      { numeroSiniestro: { contains: q.q, mode: "insensitive" } },
      { auto: { cliente: { apellido: { contains: q.q, mode: "insensitive" } } } },
    );
    const patente = normalizarPatente(q.q);
    if (patente.length >= 2) or.push({ auto: { patente: { contains: patente } } });
    const dni = normalizarDni(q.q);
    if (dni.length >= 3) or.push({ auto: { cliente: { dni: { startsWith: dni } } } });
  }

  const where: Prisma.SiniestroWhereInput = {
    sucursalId: sucursalFiltro(u, q.sucursalId),
    estado: q.estado ?? (q.activos === "true" ? { not: "ENTREGADO" } : undefined),
    ...(or.length ? { OR: or } : {}),
  };

  const POR_PAGINA = 50;
  const [total, filas] = await Promise.all([
    prisma.siniestro.count({ where }),
    prisma.siniestro.findMany({
      where,
      orderBy: { fechaIngreso: "desc" },
      skip: (q.pagina - 1) * POR_PAGINA,
      take: POR_PAGINA,
      select: {
        id: true,
        numeroSiniestro: true,
        estado: true,
        tipoCobertura: true,
        fechaIngreso: true,
        fechaEstimada: true,
        sucursal: { select: { nombre: true } },
        auto: {
          select: {
            patente: true,
            marca: true,
            modelo: true,
            cliente: { select: { id: true, dni: true, nombre: true, apellido: true } },
          },
        },
        documentos: { where: { obligatorio: true, archivoUrl: null }, select: { id: true } },
      },
    }),
  ]);

  res.json({
    total,
    pagina: q.pagina,
    porPagina: POR_PAGINA,
    siniestros: filas.map(({ documentos, ...s }) => ({ ...s, documentosFaltantes: documentos.length })),
  });
});

siniestrosRouter.get("/:id", async (req, res) => {
  const u = usuarioActual(req);
  res.json(presentar(await cargarSiniestro(u, idParam(req.params.id))));
});

// ── Edición de datos ──────────────────────────────────────────────

siniestrosRouter.patch("/:id", async (req, res) => {
  const u = usuarioActual(req);
  const id = idParam(req.params.id);
  const d = z
    .object({
      descripcion: z.string().trim().max(2000).nullable().optional(),
      fechaEstimada: z.coerce.date().nullable().optional(),
      tipoCobertura: z.enum(TIPOS_COBERTURA).optional(),
      montoFranquicia: montoSchema.nullable().optional(),
    })
    .parse(req.body);

  const actual = await cargarSiniestro(u, id);
  if (actual.estado === "ENTREGADO") throw new HttpError(409, "El siniestro ya fue entregado y no se puede modificar");

  const cobertura = d.tipoCobertura ?? actual.tipoCobertura;
  // Si cambia la cobertura y no se informa monto, se descarta el anterior
  const monto =
    d.montoFranquicia !== undefined
      ? d.montoFranquicia
      : d.tipoCobertura && d.tipoCobertura !== actual.tipoCobertura
        ? null
        : actual.montoFranquicia === null
          ? null
          : Number(actual.montoFranquicia);
  if (!coberturaValida({ tipoCobertura: cobertura, montoFranquicia: monto })) {
    throw new HttpError(400, MSG_FRANQUICIA);
  }

  await prisma.$transaction(async (tx) => {
    await tx.siniestro.update({
      where: { id },
      data: {
        descripcion: d.descripcion,
        fechaEstimada: d.fechaEstimada,
        tipoCobertura: cobertura,
        montoFranquicia: monto,
      },
    });

    // Mantener el checklist coherente con la cobertura
    const carta = actual.documentos.find((x) => x.tipoDocumento === "CARTA_FRANQUICIA");
    if (cobertura === "TODO_RIESGO_FRANQUICIA") {
      if (!carta) {
        await tx.documento.create({ data: { siniestroId: id, tipoDocumento: "CARTA_FRANQUICIA", obligatorio: true } });
      } else if (!carta.obligatorio) {
        await tx.documento.update({ where: { id: carta.id }, data: { obligatorio: true } });
      }
    } else if (carta) {
      if (carta.archivoUrl) {
        await tx.documento.update({ where: { id: carta.id }, data: { obligatorio: false } });
      } else {
        await tx.documento.delete({ where: { id: carta.id } });
      }
    }
  });

  res.json(presentar(await cargarSiniestro(u, id)));
});

// ── Cambio de estado ──────────────────────────────────────────────

siniestrosRouter.patch("/:id/estado", async (req, res) => {
  const u = usuarioActual(req);
  const id = idParam(req.params.id);
  const { estado, comentario } = z
    .object({ estado: z.enum(ESTADOS), comentario: z.string().trim().max(500).optional() })
    .parse(req.body);

  const s = await cargarSiniestro(u, id);

  if (!TRANSICIONES[s.estado].includes(estado)) {
    throw new HttpError(409, `No se puede pasar de ${s.estado} a ${estado}`, {
      permitidos: TRANSICIONES[s.estado],
    });
  }

  // Para salir de INGRESADO tiene que estar toda la documentación obligatoria
  if (s.estado === "INGRESADO") {
    const faltan = s.documentos.filter((x) => x.obligatorio && !x.archivoUrl).map((x) => x.tipoDocumento);
    if (faltan.length > 0) {
      throw new HttpError(409, "Faltan documentos obligatorios para avanzar", { faltan });
    }
  }

  await prisma.$transaction(async (tx) => {
    // Condición sobre el estado anterior: si otro usuario lo cambió en el medio, no pisa
    const r = await tx.siniestro.updateMany({
      where: { id, estado: s.estado },
      data: { estado, ...(estado === "ENTREGADO" ? { fechaEntrega: new Date() } : {}) },
    });
    if (r.count === 0) throw new HttpError(409, "El siniestro cambió de estado mientras tanto. Recargá la pantalla.");
    await tx.historialEstado.create({
      data: { estadoAnterior: s.estado, estadoNuevo: estado, comentario, siniestroId: id, usuarioId: u.id },
    });
  });

  res.json(presentar(await cargarSiniestro(u, id)));
});
