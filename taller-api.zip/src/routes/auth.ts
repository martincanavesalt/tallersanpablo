import bcrypt from "bcryptjs";
import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { prisma } from "../db";
import { HttpError } from "../errors";
import { normalizarDni } from "../lib/util";
import { firmarToken } from "../middleware/auth";

export const authRouter = Router();

const limitarIntentos = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Demasiados intentos. Probá de nuevo en 15 minutos." },
});

// Se compara contra este hash cuando el usuario no existe, para que el tiempo
// de respuesta no revele qué emails o DNI están registrados.
const HASH_FALSO = bcrypt.hashSync("clave-que-nadie-usa", 10);

// Login del personal del taller
authRouter.post("/login", limitarIntentos, async (req, res) => {
  const { email, password } = z
    .object({ email: z.string().trim().min(3), password: z.string().min(1) })
    .parse(req.body);

  const u = await prisma.usuario.findFirst({
    where: { email: { equals: email, mode: "insensitive" } },
    include: { sucursal: true },
  });
  const ok = await bcrypt.compare(password, u?.passwordHash ?? HASH_FALSO);
  if (!u || !u.activo || !ok) throw new HttpError(401, "Credenciales inválidas");

  res.json({
    token: firmarToken("usuario", u.id, 8 * 3600),
    usuario: {
      id: u.id,
      nombre: u.nombre,
      email: u.email,
      rol: u.rol,
      sucursalId: u.sucursalId,
      sucursal: u.sucursal.nombre,
    },
  });
});

// Login del portal de clientes (DNI + clave)
authRouter.post("/portal/login", limitarIntentos, async (req, res) => {
  const { dni, password } = z
    .object({ dni: z.string().min(1), password: z.string().min(1) })
    .parse(req.body);

  const c = await prisma.cliente.findUnique({ where: { dni: normalizarDni(dni) } });
  const ok = await bcrypt.compare(password, c?.passwordHash ?? HASH_FALSO);
  if (!c || !c.activo || !c.passwordHash || !ok) throw new HttpError(401, "DNI o clave incorrectos");

  res.json({
    token: firmarToken("cliente", c.id, 12 * 3600),
    cliente: { id: c.id, nombre: c.nombre, apellido: c.apellido },
  });
});
