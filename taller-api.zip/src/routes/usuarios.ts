import bcrypt from "bcryptjs";
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../db";
import { HttpError } from "../errors";
import { idParam } from "../lib/util";
import { usuarioActual } from "../middleware/auth";

// Se monta detrás de requireAdmin
export const usuariosRouter = Router();

const seleccion = {
  id: true,
  nombre: true,
  email: true,
  rol: true,
  activo: true,
  sucursalId: true,
  sucursal: { select: { nombre: true } },
} as const;

usuariosRouter.get("/", async (_req, res) => {
  res.json(await prisma.usuario.findMany({ select: seleccion, orderBy: [{ sucursalId: "asc" }, { nombre: "asc" }] }));
});

const claveSchema = z.string().min(8, "La clave debe tener al menos 8 caracteres").max(100);

usuariosRouter.post("/", async (req, res) => {
  const d = z
    .object({
      nombre: z.string().trim().min(2).max(100),
      email: z.email(),
      password: claveSchema,
      rol: z.enum(["ADMIN", "EMPLEADO"]),
      sucursalId: z.number().int().positive(),
    })
    .parse(req.body);

  if (!(await prisma.sucursal.findUnique({ where: { id: d.sucursalId } }))) {
    throw new HttpError(400, "La sucursal no existe");
  }
  if (await prisma.usuario.findFirst({ where: { email: { equals: d.email, mode: "insensitive" } } })) {
    throw new HttpError(409, "Ya existe un usuario con ese email");
  }

  const creado = await prisma.usuario.create({
    data: {
      nombre: d.nombre,
      email: d.email,
      passwordHash: await bcrypt.hash(d.password, 10),
      rol: d.rol,
      sucursalId: d.sucursalId,
    },
    select: seleccion,
  });
  res.status(201).json(creado);
});

usuariosRouter.patch("/:id", async (req, res) => {
  const yo = usuarioActual(req);
  const id = idParam(req.params.id);
  const d = z
    .object({
      nombre: z.string().trim().min(2).max(100).optional(),
      rol: z.enum(["ADMIN", "EMPLEADO"]).optional(),
      sucursalId: z.number().int().positive().optional(),
      activo: z.boolean().optional(),
      password: claveSchema.optional(),
    })
    .parse(req.body);

  if (id === yo.id && (d.activo === false || (d.rol && d.rol !== "ADMIN"))) {
    throw new HttpError(400, "No podés darte de baja ni quitarte el rol de administrador");
  }
  if (!(await prisma.usuario.findUnique({ where: { id } }))) throw new HttpError(404, "Usuario no encontrado");

  const { password, ...resto } = d;
  const actualizado = await prisma.usuario.update({
    where: { id },
    data: { ...resto, ...(password ? { passwordHash: await bcrypt.hash(password, 10) } : {}) },
    select: seleccion,
  });
  res.json(actualizado);
});
